package com.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.commons.util.InetUtils;
import org.springframework.cloud.netflix.eureka.EurekaInstanceConfigBean;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;

import com.netflix.appinfo.AmazonInfo;

@SpringBootApplication
@EnableEurekaServer
public class EurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaServerApplication.class, args);
	}
	
	@Bean
	@Profile("!default")
	public EurekaInstanceConfigBean  eurekaInstanceConfig(InetUtils inetUtils) {
		EurekaInstanceConfigBean configBean=new EurekaInstanceConfigBean(inetUtils);
		AmazonInfo info=AmazonInfo.Builder.newBuilder().autoBuild("eureka");
		configBean.setDataCenterInfo(info);
		return configBean;
	}

}
